#pragma once
class Coordenadas{
public:
	int x;
	int y;
};

